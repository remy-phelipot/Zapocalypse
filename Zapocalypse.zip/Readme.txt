Launch with arguments :
progName nbHexagonX nbHexagonY
